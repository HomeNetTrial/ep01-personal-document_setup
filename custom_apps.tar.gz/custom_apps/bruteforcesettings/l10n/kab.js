OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Rnu",
    "Delete" : "Kkes"
},
"nplurals=2; plural=(n != 1);");
