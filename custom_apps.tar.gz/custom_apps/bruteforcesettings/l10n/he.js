OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "הגדרות כוח ברוטלי",
    "Whitelist IPs" : "כתובות IP ברשימת היתר",
    "Brute-force IP whitelist" : "רשימת היתר IP לכוח ברוטלי",
    "Add new whitelist" : "הוספת רשימת היתר חדשה",
    "Add" : "הוספה",
    "Delete" : "מחיקה"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
