OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Qo'shish",
    "Delete" : "O'chir"
},
"nplurals=1; plural=0;");
