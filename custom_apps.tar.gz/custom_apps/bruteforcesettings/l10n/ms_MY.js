OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Tambah",
    "Delete" : "Padam"
},
"nplurals=1; plural=0;");
