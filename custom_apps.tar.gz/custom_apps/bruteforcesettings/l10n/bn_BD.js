OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "যোগ করুন",
    "Delete" : "মুছে"
},
"nplurals=2; plural=(n != 1);");
