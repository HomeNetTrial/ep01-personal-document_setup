OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "เพิ่ม",
    "Delete" : "ลบ"
},
"nplurals=1; plural=0;");
