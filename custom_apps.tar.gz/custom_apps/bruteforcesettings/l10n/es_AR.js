OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Ajustes de fuerza-bruta",
    "Brute-force IP whitelist" : "IPs en lista blanca de fuerza-bruta",
    "Add" : "Añadir",
    "Delete" : "Eliminar"
},
"nplurals=2; plural=(n != 1);");
