OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "قوش",
    "Delete" : "ئۆچۈر"
},
"nplurals=2; plural=(n != 1);");
