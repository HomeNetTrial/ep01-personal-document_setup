OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "﻿ಸೇರಿಸಿ",
    "Delete" : "﻿ಅಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
