OC.L10N.register(
    "bruteforcesettings",
    {
    "Delete" : "ລຶບ"
},
"nplurals=1; plural=0;");
