OC.L10N.register(
    "bruteforcesettings",
    {
    "Whitelist IPs" : "Дозволена листа на IP адреси",
    "Add new whitelist" : "Додади нова дозволена листа",
    "Add" : "Додади",
    "Delete" : "Избриши"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
