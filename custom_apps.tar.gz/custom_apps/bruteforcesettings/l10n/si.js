OC.L10N.register(
    "bruteforcesettings",
    {
    "Whitelist IPs" : "සුදු ලැයිස්තුගත අ.ජා. කෙ. (IPs)",
    "Add new whitelist" : "නව සුදු ලැයිස්තුවක් එකතු කරන්න",
    "Add" : "එකතු කරන්න"
},
"nplurals=2; plural=(n != 1);");
