OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Väsytyshyökkäyksen asetukset",
    "Whitelist IPs" : "Sallitut IP:t",
    "Brute-force IP whitelist" : "Turvallisten IP-osoitteiden lista",
    "Add new whitelist" : "Lisää uusi sallittujen lista",
    "Add" : "Lisää",
    "Delete" : "Poista"
},
"nplurals=2; plural=(n != 1);");
