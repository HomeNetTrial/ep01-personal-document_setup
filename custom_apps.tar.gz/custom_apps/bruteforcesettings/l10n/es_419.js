OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Configuracion de fuerza bruta",
    "Brute-force IP whitelist" : "Lista blanca de IP de fuerza bruta",
    "Add" : "Agregar",
    "Delete" : "Borrar"
},
"nplurals=2; plural=(n != 1);");
