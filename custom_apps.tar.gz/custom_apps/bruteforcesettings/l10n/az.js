OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Əlavə etmək",
    "Delete" : "Sil"
},
"nplurals=2; plural=(n != 1);");
