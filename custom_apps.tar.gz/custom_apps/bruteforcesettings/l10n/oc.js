OC.L10N.register(
    "bruteforcesettings",
    {
    "Add new whitelist" : "Apondre una lista blanca",
    "Add" : "Apondre",
    "Delete" : "Suprimir"
},
"nplurals=2; plural=(n > 1);");
