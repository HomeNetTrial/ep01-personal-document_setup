OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Настройки за атаки \"груба сила\"",
    "Brute-force IP whitelist" : "IP бял списък за атаки \"груба сила\"",
    "Add" : "Добавяне",
    "Delete" : "Изтриване"
},
"nplurals=2; plural=(n != 1);");
