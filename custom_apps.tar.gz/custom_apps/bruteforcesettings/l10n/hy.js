OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "Ավելացնել",
    "Delete" : "հեռացնել"
},
"nplurals=2; plural=(n != 1);");
