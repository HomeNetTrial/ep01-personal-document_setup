OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Cài đặt Brute-force",
    "Brute-force IP whitelist" : "Brute-force IP whitelist",
    "Add" : "Thêm",
    "Delete" : "Xóa"
},
"nplurals=1; plural=0;");
