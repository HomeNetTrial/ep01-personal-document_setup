OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "បញ្ចូល",
    "Delete" : "លុប"
},
"nplurals=1; plural=0;");
