OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Konfigurimet e brute-force",
    "Brute-force IP whitelist" : "Brute-force listën e bardhë të IP-ve ",
    "Add" : "Shto",
    "Delete" : "Delete"
},
"nplurals=2; plural=(n != 1);");
