OC.L10N.register(
    "external",
    {
    "Select an icon" : "ಚಿಹ್ನೆ ಒಂದನ್ನು ಆಯ್ಕೆ ಮಾಡಿ",
    "__language_name__" : "ಕನ್ನಡ",
    "Name" : "﻿ಹೆಸರು",
    "URL" : "ಜಾಲದ ಕೊಂಡಿ",
    "Language" : "﻿ಭಾಷೆ",
    "Groups" : "﻿ಗುಂಪುಗಳು",
    "Remove site" : " ಅಂತರ್ಜಾಲದ ತಾಣವನ್ನು ತೆಗೆದುಹಾಕಿ",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "ದಯವಿಟ್ಟು ಗಮನಿಸಿ, ಕೆಲವು ಅಂತರ್ಜಾಲವನ್ನು ಶೋಧಿಸುವ ತಂತ್ರಾಂಶಗಳು HTTPS ಮೂಲದ ಸುರಕ್ಷಿತ ತಾಣಗಳನ್ನು ತೆರೆಯುವಾಗ ಸಾಧಾರಣ HTTP ಸಂಬಂಧಿತ ಕೊಂಡಿಗಳನ್ನು  ನಿರ್ಬಂಧಿಸುತ್ತವೆ.",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "ಇದಲ್ಲದೆ ಈ ದಿನಗಳಲ್ಲಿ  ಭದ್ರತೆ ಕಾರಣಗಳಿಂದಾಗಿ ಅನೇಕ ತಾಣಗಳು  IFRAME ಗಳನ್ನು  ತಡೆಹಿಡಿಯಬಹುದೆಂದು  ಗಮನಿಸಿ."
},
"nplurals=2; plural=(n > 1);");
