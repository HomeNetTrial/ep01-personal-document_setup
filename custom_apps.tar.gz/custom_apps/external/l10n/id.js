OC.L10N.register(
    "external",
    {
    "Select an icon" : "Pilih ikon",
    "All languages" : "Semua bahasa",
    "No file uploaded" : "Tidak ada file diunggah",
    "__language_name__" : "Bahasa Indonesia",
    "Name" : "Nama",
    "URL" : "URL",
    "Language" : "Bahasa",
    "Groups" : "Grup",
    "Remove site" : "Hapus situs",
    "Uploading…" : "Menunggah…",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "Mohon dicatat bahwa beberapa peramban akan memblokir untuk menampilkan situs via http jika Anda menjalankan https.",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "Lebih lanjut perlu diketahui bahwa banyak situs saat ini tidak mengizinkan iframing karena alasan keamanan.",
    "Icons" : "Ikon"
},
"nplurals=1; plural=0;");
