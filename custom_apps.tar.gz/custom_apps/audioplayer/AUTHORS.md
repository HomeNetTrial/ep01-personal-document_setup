# Authors

* [Marcel Scherello](https://github.com/rello) <audioplayer@scherello.de> (project leader)

## Contributors

* [r4sas](https://github.com/r4sas)
* [Martin Matous](https://github.com/mmatous)