<?php
$appId = OCA\Zammad\AppInfo\Application::APP_ID;
script($appId, $appId . '-personalSettings');
?>

<div id="zammad_prefs"></div>