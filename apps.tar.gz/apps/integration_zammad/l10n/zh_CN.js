OC.L10N.register(
    "integration_zammad",
    {
    "Error during OAuth exchanges" : "交换 OAuth 时出错",
    "Bad credentials" : "不好的证书",
    "OAuth access token refused" : "OAuth 访问令牌拒绝",
    "Connected accounts" : "关联账号",
    "Enable navigation link" : "启用导航链接",
    "Connected as {user}" : "作为 {user} 已连接",
    "Incorrect access token" : "访问令牌不正确"
},
"nplurals=1; plural=0;");
