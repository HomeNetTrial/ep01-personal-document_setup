OC.L10N.register(
    "external",
    {
    "Select an icon" : "เลือกไอคอน",
    "__language_name__" : "ภาษาไทย - Thai languages",
    "Name" : "ชื่อ",
    "URL" : "URL",
    "Language" : "ภาษา",
    "Groups" : "กลุ่ม",
    "Redirect" : "เปลี่ยนเส้นทาง",
    "Remove site" : "ลบเว็บไซต์ออก",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "โปรดทราบว่าเบราว์เซอร์จะปิดกั้นการแสดงเว็บไซต์บางส่วนผ่าน HTTP ถ้าคุณใช้ HTTPS",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "นอกจากนี้โปรดทราบว่าหลายเว็บไซต์ ไม่อนุญาตให้ใช้ iframe เนื่องจากเหตุผลด้านความปลอดภัย"
},
"nplurals=1; plural=0;");
