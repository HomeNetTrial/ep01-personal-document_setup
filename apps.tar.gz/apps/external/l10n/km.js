OC.L10N.register(
    "external",
    {
    "__language_name__" : "ភាសាខ្មែរ",
    "Name" : "ឈ្មោះ",
    "URL" : "URL",
    "Language" : "ភាសា",
    "Groups" : "ក្រុ",
    "Remove site" : "លុប​វេបសាយ"
},
"nplurals=1; plural=0;");
