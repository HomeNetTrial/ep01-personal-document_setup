OC.L10N.register(
    "external",
    {
    "All languages" : "සියලුම භාෂා",
    "All devices" : "සියලුම උපාංග",
    "Only in the Android app" : "ඇන්ඩ්‍රොයිඩ් යෙදුමේ පමණි",
    "The given device is invalid" : "දී ඇති උපාංගය වලංගු නොවේ",
    "The site does not exist" : "වියමන අඩවිය නොපවතී",
    "__language_name__" : "__language_name__",
    "Name" : "නම",
    "Language" : "භාෂාව",
    "Groups" : "සමූහ…",
    "Uploading…" : "උඩුගත වෙමින්…"
},
"nplurals=2; plural=(n != 1);");
