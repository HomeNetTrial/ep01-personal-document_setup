OC.L10N.register(
    "external",
    {
    "__language_name__" : "اردو",
    "Name" : "اسم",
    "URL" : "یو ار ایل",
    "Remove site" : "سائٹ ہٹایں"
},
"nplurals=2; plural=(n != 1);");
