OC.L10N.register(
    "external",
    {
    "Select an icon" : "Selige un icone",
    "__language_name__" : "Interlingua de IALA",
    "Name" : "Nomine",
    "URL" : "URL",
    "Language" : "Lingua",
    "Groups" : "Gruppos",
    "Remove site" : "Remove sito",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "Pro favor nota que alcun navigatores blocara le monstrar de sitos via http si tu es executante https.",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "Ulteriormente nota que multe sitos iste dies dishabilita iframing debite a motivationes de securitate."
},
"nplurals=2; plural=(n != 1);");
