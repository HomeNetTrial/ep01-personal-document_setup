OC.L10N.register(
    "external",
    {
    "Select an icon" : "Seleccionar una icòna",
    "All languages" : "Totas las lengas",
    "The given language does not exist" : "La lenga especificada existís pas",
    "Name" : "Nom",
    "URL" : "URL",
    "Language" : "Lenga",
    "Groups" : "Gropes",
    "Remove site" : "Suprimir lo site",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "Notatz que certans navigadors pòdon blocar l’afichatge dels sites via http se utilizatz https.",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "D'una autra costat, notatz que fòrça sites interdison l’utilizacion dels iframes per de rasons de seguretat."
},
"nplurals=2; plural=(n > 1);");
