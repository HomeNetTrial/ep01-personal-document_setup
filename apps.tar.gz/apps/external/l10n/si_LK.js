OC.L10N.register(
    "external",
    {
    "__language_name__" : "සිංහල",
    "Name" : "නම",
    "URL" : "URL",
    "Language" : "භාෂාව",
    "Groups" : "කණ්ඩායම්",
    "Remove site" : "වෙබ් අඩවිය ඉවත් කරන්න"
},
"nplurals=2; plural=(n != 1);");
