OC.L10N.register(
    "external",
    {
    "__language_name__" : "Nynorsk",
    "Name" : "Namn",
    "URL" : "Nettstad",
    "Language" : "Språk",
    "Groups" : "Grupper",
    "Remove site" : "Fjern nettstad"
},
"nplurals=2; plural=(n != 1);");
