OC.L10N.register(
    "external",
    {
    "Select an icon" : "選擇圖示",
    "__language_name__" : "繁體中文（香港）",
    "Name" : "名稱",
    "URL" : "網址",
    "Language" : "語言",
    "Groups" : "群組",
    "Remove site" : "移除網站",
    "Please note that some browsers will block displaying of sites via http if you are running https." : "請注意如果你運行https有些瀏覽器會禁示顯示使用http 的網站",
    "Furthermore please note that many sites these days disallow iframing due to security reasons." : "此外, 請注意現時很多網站由於安全理由禁止使用內聯框架 "
},
"nplurals=1; plural=0;");
