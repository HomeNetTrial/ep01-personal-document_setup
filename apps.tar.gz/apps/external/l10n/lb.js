OC.L10N.register(
    "external",
    {
    "__language_name__" : "Lëtzebuergesch",
    "Name" : "Numm",
    "URL" : "URL",
    "Language" : "Sprooch",
    "Groups" : "Gruppen",
    "Remove site" : "Site läschen"
},
"nplurals=2; plural=(n != 1);");
