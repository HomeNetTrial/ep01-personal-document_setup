OC.L10N.register(
    "external",
    {
    "__language_name__" : "Bahasa Melayu",
    "Name" : "Nama",
    "URL" : "URL",
    "Language" : "Bahasa",
    "Groups" : "Kumpulan",
    "Remove site" : "Buang laman"
},
"nplurals=1; plural=0;");
