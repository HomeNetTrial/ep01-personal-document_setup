OC.L10N.register(
    "notes",
    {
    "Notes" : "شسیب",
    "Error" : "شسیب",
    "Settings" : "سمونې",
    "Today" : "نن",
    "Yesterday" : "پرون",
    "Rename" : "نوم بدلول",
    "Remove from favorites" : "له نښو ويستل",
    "Add to favorites" : "په نښه کول",
    "Details" : "معلومات"
},
"nplurals=2; plural=(n != 1);");
