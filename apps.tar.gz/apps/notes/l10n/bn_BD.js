OC.L10N.register(
    "notes",
    {
    "Notes" : "নোট",
    "Error" : "সমস্যা",
    "New note" : "নতুন নোট",
    "Settings" : "সেটিংস",
    "Today" : "আজ",
    "Yesterday" : "গতকাল",
    "Rename" : "পূনঃনামকরণ",
    "Delete note" : "নোট মোছ",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "বিসতারিত",
    "Edit" : "সম্পাদনা"
},
"nplurals=2; plural=(n != 1);");
