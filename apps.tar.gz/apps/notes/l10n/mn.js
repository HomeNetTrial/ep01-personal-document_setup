OC.L10N.register(
    "notes",
    {
    "Notes" : "Тэмдэглэл",
    "Error" : "Алдаа",
    "New note" : "Шинэ тэмдэглэл",
    "Settings" : "Тохиргоо",
    "No notes yet" : "шинэ тэмдэглэл алга",
    "All notes" : "Бүх тэмдэг",
    "Categories" : "төрөл",
    "Today" : "өнөөдөр",
    "Yesterday" : "өчигдөр",
    "This week" : "7 хоног",
    "This month" : "1 сар",
    "Rename" : "Нэрлэнэ үү",
    "Delete note" : "Тэмдэглэл устгах",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Дэлгэрэнгүй",
    "Edit" : "засварлах",
    "Preview" : "шалгах",
    "Category" : "Ангилал"
},
"nplurals=2; plural=(n != 1);");
