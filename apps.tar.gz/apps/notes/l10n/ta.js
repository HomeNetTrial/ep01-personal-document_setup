OC.L10N.register(
    "notes",
    {
    "Notes" : "குறிப்புகள்",
    "Error" : "வழு",
    "Settings" : "அமைப்புகள்",
    "Today" : "இன்று",
    "Rename" : "பெயர்மாற்றம்",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "விவரங்கள்",
    "Edit" : "தொகுக்க"
},
"nplurals=2; plural=(n != 1);");
