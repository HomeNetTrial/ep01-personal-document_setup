OC.L10N.register(
    "notes",
    {
    "Notes" : "Notes",
    "Error" : "﻿ತಪ್ಪಾಗಿದೆ",
    "Settings" : "ಆಯ್ಕೆ",
    "Today" : "Today",
    "Rename" : "﻿ಮರುಹೆಸರಿಸು",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "ಸಂಪಾದಿಸು"
},
"nplurals=2; plural=(n > 1);");
