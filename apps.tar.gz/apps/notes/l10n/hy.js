OC.L10N.register(
    "notes",
    {
    "Notes" : "Նոթեր",
    "Error" : "Սխալ",
    "New note" : "Նոր նոթ",
    "Settings" : "կարգավորումներ",
    "No notes yet" : "առայժմ գրառում չկա",
    "Today" : "այսօր",
    "Yesterday" : "երեկ",
    "This week" : "այս շաբաթ",
    "This month" : "այս ամիս",
    "Rename" : "Վերանվանել",
    "Delete note" : "Ջնջել նոթը",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Details" : "Մանրամասներ",
    "Edit" : "մշակել",
    "_%n word_::_%n words_" : ["%n բառ","%n բառ"]
},
"nplurals=2; plural=(n != 1);");
