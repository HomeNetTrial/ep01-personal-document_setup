OC.L10N.register(
    "notes",
    {
    "Notes" : "Notas",
    "Error" : "Errore",
    "Settings" : "Impostatziones",
    "Rename" : "Torra a numenare",
    "Details" : "Detàllios",
    "Edit" : "Modìfica ",
    "Preview" : "Anteprima"
},
"nplurals=2; plural=(n != 1);");
