OC.L10N.register(
    "notes",
    {
    "Notes" : "Nota",
    "Error" : "Ralat",
    "New note" : "Note baharu",
    "Settings" : "Tetapan",
    "Today" : "Hari ini",
    "Yesterday" : "Semalam",
    "Rename" : "Namakan",
    "Delete note" : "Hapus nota",
    "Remove from favorites" : "Remove from favorites",
    "Add to favorites" : "Add to favorites",
    "Edit" : "Sunting"
},
"nplurals=1; plural=0;");
